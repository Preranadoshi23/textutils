import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'StudentDb';
  baseUrl="http://65.2.140.241:8080/bhushansystem/";

  name:String='';
  marks:number=0;

  students:any;
  isLoggedIn:number=0;
  username:string='';
  password:string='';
  login()
  {
let url=this.baseUrl+'login'+this.username
this.http.post(url,this.password).subscribe((data:any)=>
{
if(data==1)
{
  this.isLoggedIn=1;
}
else
{
  alert('Invalid credentials')
}
});
  }
  logout()
  {
    this.isLoggedIn=0;
  }
  constructor(public http:HttpClient)
  {
    let url=this.baseUrl+'get';
    this.http.get(url).subscribe(
      (data: any) => {
        this.students = data;
      });
  }

  delete(student:any)
  {
    let url=this.baseUrl+'delete'+student.id;
    this.http.get(url).subscribe( (data: any) => {
      if(data==1)
      {
        let index=this.students.indexOf(student);
        if(index>=0)
        {
          this.students.splice(index,1);
        }
      }
      else
      {
        alert('Exception on server');
      }
      });
  }
  add()
  {
    let obj=
    {
      "name":this.name,
      "marks":this.marks
    }
    let url=this.baseUrl+'add';
    this.http.post(url,obj).subscribe((data: any) =>
    {
      if(data==null)
      {
        alert("Exception on server");
      }
      else
      {
        this.students.push(data);
        this.name='';
        this.marks=0;
      }
    });
  }
}